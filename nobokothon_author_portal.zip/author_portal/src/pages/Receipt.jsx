import { useParams } from "react-router-dom";
import { Camera, FileDown, Printer } from "lucide-react";
import { IMAGE_BASE } from "@/lib/api";
import { useAdvance, usePayout, useSummary } from "@/lib/queries";
import { ReceiptCard } from "@/components/Receipts";
import { Button, ErrorBox, PageTitle, Spinner } from "@/components/ui";

// Advance Receipt / Withdraw Receipt / Withdraw Request pages (designs 18, 20, 22).
// "Download PDF" opens the print dialog, where the author picks "Save as PDF".
export default function Receipt() {
  const { kind, id } = useParams();
  const advance = useAdvance(kind === "advance" ? id : null);
  const payout = usePayout(kind === "withdraw" ? id : null);
  const { data: summary } = useSummary();
  const query = kind === "advance" ? advance : payout;
  const item = query.data;
  const title = kind === "advance" ? "Advance Receipt" : item?.status === "paid" ? "Withdraw Receipt" : "Withdraw Request";

  return (
    <>
      <PageTitle
        title={title}
        back={kind === "advance" ? "/royalty-history" : "/withdraw-history"}
        right={item && (
          <div className="no-print flex gap-2">
            {item.proof && <a href={`${IMAGE_BASE}/upload/${item.proof}`} target="_blank" rel="noreferrer"><Button variant="outline"><Camera className="size-4" /> Payment proof</Button></a>}
            <Button variant="outline" onClick={() => window.print()}><FileDown className="size-4" /> Download PDF</Button>
            <Button variant="outline" onClick={() => window.print()}><Printer className="size-4" /> Print</Button>
          </div>
        )}
      />
      {query.isLoading ? <Spinner /> : query.error ? <ErrorBox error={query.error.message} /> : item && <ReceiptCard item={item} kind={kind} author={summary?.author} />}
    </>
  );
}
